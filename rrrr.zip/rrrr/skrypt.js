if(userid!=0){
    logowanie = document.getElementById('logowanie').style.display='none';
};

console.log(userid);

if(userid==0){
    wylogowanie=document.getElementById('log_out').style.display='none';
    profile=document.getElementById('profile').style.display='none';
    dodawanie=document.getElementById('add').style.display='none';
};

