<?php 
session_start();


header('location:index.php');
$_SESSION['id']=0;


?>
